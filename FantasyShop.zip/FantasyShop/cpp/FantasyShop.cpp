#include "ShopApp.h"

int main()
{
	ShopApp shop;
	shop.Run();
}
